#include "StringSet.h"


StringSet::StringSet() {
	//stub method
}


bool StringSet::insert(std::string s) {
	//stub method

	return false;
}


void StringSet::remove(std::string s) {
	//stub method
}


int StringSet::size() {
	//stub method

	return 0;
}


int StringSet::find(std::string s) {
	//stub method

	return 0;
}
